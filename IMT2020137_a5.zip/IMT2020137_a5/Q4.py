def is_wellformed(lst):
    for i in range (len(lst)):
        if(len(lst[0]) == len(lst[i])):
            pass
        else:
            return False
    return True

def are_addable(ls1, ls2):
    if(is_wellformed(ls1) and is_wellformed(ls2)):
        if(len(ls1) == len(ls2) and len(ls1[0]) == len(ls2[0])):
            return True
    return False

def are_multipliable(ls1, ls2):
    if(is_wellformed(ls1) and is_wellformed(ls2)):
        if(len(ls1[0]) == len(ls2)):
            return True
    return False

def scalar_multiply_list(n, lst):
    return [n*i for i in lst]

def scalar_multiply_matrix(n, ls):
    nlst = []
    for i in range(len(ls)):
        nlst.append(scalar_multiply_list(n,ls[i]))
    return nlst

def add_lists(ls1, ls2):
    nlst = []
    for i in range(len(ls1)):
        nlst.append(ls1[i] + ls2[i])
    return nlst

def add_matrices(m1, m2):
    if(are_addable(m1,m2)):
        nlst = []
        for i in range(len(m1)):
            nlst.append(add_lists(m1[i], m2[i]))
        return nlst
    print("Invalid matrices")

def multiply_lists(l1, l2):
    nlst = []
    for i in range(len(l1)):
        nlst.append(l1[i] * l2[i])
    return nlst

def transpose(mat):
    trans = [[mat[i][j] for i in range(len(mat))] for j in range(len(mat[0]))]
    return trans

def multiply_matrices(m1, m2):
    if(are_multipliable(m1, m2)):
        nlst = []
        transm2 = transpose(m2)
        for i in range(len(m1)):
            for j in range(len(m2[0])):
                nlst.append(multiply_lists(m1[i], transm2[j])) 
        
        tlst = []
        for i in nlst:
            sum = 0
            for j in range(len(i)):
                sum = sum + i[j]
            tlst.append(sum)
        final = []
        temp = []
        for i in range(len(m1)*len(m2[0])):
            temp.append(tlst[i])
            if((i+1) % len(m2[0]) == 0):
                final.append(temp)
                temp = []
        return final
    print("Invalid matrices")

if __name__ == "__main__":
    print ( is_wellformed ([[1 , 2 , 3] , [20 , 40 , 50]]))
    print ( is_wellformed ([[1 , 2 , 3] , [20 , 40]]))
    print ( are_addable ([[1 , 2 , 3] , [20 , 40 , 50]] , [[1 , 2 , 3] , [20 , 40 , 50]]    ))
    print ( are_addable ([[1 , 2] , [20 , 40]] , [[1 , 2 , 3] , [20 , 40 , 50]]    ))
    print ( are_multipliable ([[1 , 2 , 3] , [20 , 40 , 50]] , [[1 , 2 , 3] , [20 , 40 , 50]]    ))
    print ( are_multipliable ([[1 , 2] , [20 , 40]] , [[1 , 2 , 3] , [20 , 40 , 50]]    ))
    print ( scalar_multiply_list( 3 , [1 , 2 , 3]   ))
    print ( scalar_multiply_matrix(3, [[1, 2, 3],[2, 4, 6]]     ))
    print ( add_lists([1,2,3],[2,3,1]    ))
    print ( add_matrices ([[1 , 2 , 3]] , [[4 , 5 , 6]]    ))
    print ( multiply_lists ([1 , 2 , 3] , [4 , 5 , 6]))
    print ( multiply_matrices ([[1 , 2 , 3] ,[4 , 5, 6]],[[7 , 10] , [8 , 11] , [9 , 12]]))
