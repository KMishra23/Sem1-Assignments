def increment(a):
    return (a+1)

def decrement(a):
    return (a-1)

def add(a, b):
    for i in range(b):
        a = increment(a)
    return a

def subtract(a, b):
    for i in range(b):
        a = decrement(a)
    return a

def multiply(a, b):
    temp = a
    for i in range(b-1):
        a = add(a,temp)
    return a

def divide(a, b):
    count = 0
    while(count >= 0):
        if(a < b):
            break
        a = subtract(a,b)
        count = increment(count)
    return count

def exponent(a, b):
    temp = a
    for i in range(b-1):
        a = multiply(a,temp)
    return a

if __name__ == "__main__":
    print(increment(2))
    print(decrement(2))
    print(add(2, 3))
    print(subtract(2, 3))
    print(multiply(5, 6))
    print(divide(7, 2))
    print(exponent(2, 3))
