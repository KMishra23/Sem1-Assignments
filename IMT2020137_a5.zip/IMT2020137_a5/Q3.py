def product_of_list(lst):
    product = 1
    for a in lst:
        product = product*a
    return product

def reduce_terms(lst):
    product = []
    for i in range(len(lst)):
       product.append(product_of_list(lst[i]))
    return product

def sum_of_list(lst):
    sum = 0
    for a in lst:
        sum = sum + a 
    return sum

def evaluate_SOP(lst):
    return (sum_of_list(reduce_terms(lst)))

if __name__ == "__main__":
    print(product_of_list([1,2,3]))
    print(reduce_terms([[1,2,3],[20,40]]))
    print(sum_of_list([6,800]))
    print(evaluate_SOP([[1,2,3],[20,40]]))

