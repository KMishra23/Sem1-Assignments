from datetime import date

class Employee:
    emp_count = 0
    def __init__(self,emp_name,dob):
        Employee.emp_count += 1
        self.emp_name = emp_name
        self.dob = dob
        self.emp_id = Employee.emp_count
        self.age = int(date.today().year - dob[2])
        self.work_exp = []
   
    def checkSpecialEligibility(self):
        if(self.age>=50):
            return True
        return False

    def addWorkExperience(self, previous_companies):
        self.work_exp += previous_companies

    def getWorkExperience(self):
        return self.work_exp

    def __str__(self):
        return "Employee ID: " + str(self.emp_id) +", Employee Name: "+ str(self.emp_name) +", Employee Age = "+ str(self.age) + " years"

def t3():
    e1 = Employee("Ajay", (21,3,1992))
    e2 = Employee("Rakesh", (31,12, 1990))
    e3 = Employee("Manoj", (2,2,1970))
    print(e1.checkSpecialEligibility())
    print(e3.checkSpecialEligibility())
    e2.addWorkExperience(["Amazon", "Morgan Stanley"])
    e2.addWorkExperience(["Microsoft", "Goldman Sachs"])
    print(e2.getWorkExperience())
    print(e1)
    print(e2)
    print(e3)
if __name__ == "__main__":
    t3()



