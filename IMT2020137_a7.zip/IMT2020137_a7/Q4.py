class Student:
    def __init__(self,roll_num,stu_name,department,jee_rank):
        self.roll_num = roll_num
        self.stu_name = stu_name
        self.department = department
        self.jee_rank = jee_rank
        self.courses_enrolled = []

class Professor:
    def __init__(self,prof_id,prof_name,department,courses_taught):
        self.prof_id = prof_id
        self.prof_name = prof_name
        self.department = department
        self.courses_taught = courses_taught

class Institution:
    def __init__(self,inst_name,location,department_list,profs_list,students_list):
        self.inst_name = inst_name
        self.location = location
        self.department_list = department_list
        self.profs_list = profs_list
        self.students_list = students_list
        self.no_profs = len(profs_list)
        self.no_students = len(students_list)
        self.no_deps = len(department_list)

    def __str__(self):
        s = self.department_list[0]
        for i in range(1,len(self.department_list)):
            s += ', ' + self.department_list[i]
        return 'Institution '+self.inst_name+' is located in '+self.location+' and has '+str(self.no_profs)+' professors and '+str(self.no_students)+' students. It has '+str(self.no_deps)+' departments: '+s

    def enrollStudent(self,s,course_name):
        for i in self.profs_list:
            for j in i.courses_taught:
                if(j == course_name):
                    if(i.department == s.department):
                        print("Enrolled successfully")
                        s.courses_enrolled.append(course_name)
                        return 
                    else:
                        print("Not eligible to enroll in "+course_name)
                        return
        print("Invalid course name")
        return

    def findToppers(self,n=1):
        ranks = []
        for i in self.students_list:
            ranks.append(i.jee_rank)
        ranks.sort()
        name = []
        for i in range(n):
            for j in self.students_list:
                if(ranks[i] == j.jee_rank):
                    name.append(j.stu_name)
        return name

def t4():
    s1 = Student(1, "Vikram", "CSE", 5500)
    s2 = Student(2, "Samrudhhi", "ECE", 2500)
    s3 = Student(3, "Apoorv", "ECE", 6300)
    s4 = Student(4, "Chaitanya", "CSE", 9500)
    s5 = Student(5, "Akanksha", "CSE", 3200)
    s6 = Student(6, "Akshita", "ECE", 5700)
    p1 = Professor(1, "Sanjay", "CSE", ["Java", "Computer Graphics"])
    p2 = Professor(2, "Ajeesh", "CSE", ["Programming Languages", "Compilers"])
    p3 = Professor(3, "Nirmal", "ECE", ["VLSI"])
    p4 = Professor(4, "Shantanu", "ECE", ["Processor Architecture", "RTOS"])
    p5 = Professor(5, "Rajesh", "CSE", ["ML", "Visual Recognition", "NLP"])
    p6 = Professor(6, "Geetha", "ECE", ["Digital Design"])
    p7 = Professor(7, "Anusha", "CSE", ["DSA", "Graph Theory"])
    inst1 = Institution("IIITB", "Bangalore", ["CSE", "ECE"],[p1, p2, p3, p6], [s1, s2, s3])
    inst2 = Institution("IITD", "Delhi", ["CSE", "ECE", "EEE"],
    [p4, p5, p7], [s4, s5, s6])
    inst1.enrollStudent(s1, "Java")
    inst1.enrollStudent(s1, "C")
    inst1.enrollStudent(s1, "Compilers")
    inst1.enrollStudent(s2, "Computer Graphics")
    print(inst1.findToppers(2))
    print(inst2.findToppers())
    print(inst2)
if __name__ == "__main__":
    t4()
