class Vehicle:
    def __init__(self,name,brand,price,mileage):
        self.name = str(name)
        self.brand = str(brand)
        self.price = float(price)
        self.mileage = float(mileage)

    def checkLuxury(self):
        if(self.price > 1000000):
            return True
        return False

    def checkEfficiency(self):
        if(self.mileage > 20):
            return True
        return False

    def __str__(self):
        return("Vehicle Name: "+self.name+", Brand: "+self.brand+", Price: "+str(self.price)+", Mileage: "+str(self.mileage))

def efficientVehicles(lst):
    nlst = []
    for i in lst:
        if i.checkEfficiency():
            nlst.append(i.name)
    return nlst

def priceOfBrand(brand, lst):
    total = 0
    for i in lst:
        if (brand == i.brand):
            total += i.price
    return total

def t1():
    v1 = Vehicle("Alto","Suzuki",100000.0,50.0)
    v2 = Vehicle("SX4","Suzuki",200000.0,35.5)
    v3 = Vehicle("R8","Audi",1000000.0,15.7)
    v4 = Vehicle("Q3","Audi",1500000.0,18.5)

    print(v1.checkLuxury())
    print(v2.checkEfficiency())
    print("Efficient Vehicles: ", efficientVehicles([v1, v2, v3, v4]))
    audiPrice = priceOfBrand("Audi", [v1, v2, v3, v4])
    print("Audi price:",audiPrice)
    print(v1)

if __name__ == "__main__":
    t1()
