def leap(day,month,year):
    if(year % 4 == 0):
        return True
    return False

def valid(day,month,year):
    if(day == 31):
        if(month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 or month == 12):
            return True
        else:
            return False
    elif(day == 29):
        if(month == 2):
            if(leap(day,month,year)):
               return True
            else:
                return False
        else:
            return True
    elif(day == 30):
        if(month == 2):
            return False
        else:
            return True
    elif(day <= 0 or day > 31):
        return False
    elif(month > 12 or month < 1):
        return False
    elif(year > 2021 or year < 0):
        return False
    return True


class Date:
    def __init__(self,day,month,year):
        self.valid = valid(day,month,year)
        if(self.valid):
            self.day = int(day)
            self.month = int(month)
            self.year = int(year)
        else:
            print("Invalid date")
    
    def tomorrow(self):
        if(not(self.valid)):
            return 'Cannont find next day for invalid date'
        else:
            if(self.day == 30 and (self.month == 4 or self.month == 6 or self.month == 9 or self.month == 11)):
                return (1,self.month + 1,self.year)
            elif(self.day == 31 and self.month == 12):
                return (1,1,self.year+1)
            elif(self.day == 31):
                return (1,self.month + 1, self.year + 1)
            elif(self.day == 28 and self.month == 2 and leap(self.day,self.month,self.year)):
                return (29,2,self.year)
            elif(self.day == 28 and self.month == 2):
                return (1,3,self.year)
            else:
                return (self.day + 1,self.month,self.year)



def t2():
    d1 = Date(15,8,2002)
    print(d1.tomorrow())

    d2 = Date(29,2,2021)
    print(d2.tomorrow())

    d3 = Date(31,6,1842)
    print(d3.tomorrow())

    d4 = Date(25,3,2022)
    print(d4.tomorrow())

    d5 = Date(16,13,1257)
    print(d5.tomorrow())

    d6 = Date(-7,-3,-2001)
    print(d6.tomorrow())

    d7 = Date(28,2,2021)
    print(d7.tomorrow())

    d8 = Date(31,12,1999)
    print(d8.tomorrow())

if __name__ == "__main__":
    t2()
