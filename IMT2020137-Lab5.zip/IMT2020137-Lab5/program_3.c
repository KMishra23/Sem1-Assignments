#include <stdio.h>

int main() {
	int n, grace;
	char c;
	scanf("%c %d",&c, &n);
	switch(c) {//switch that uses input from entered char c
		case 'f': grace = (n > 3) ? (0) : (n * 5);//ternary operation that checks if grace should be given and calculates grace
			  printf("%d",grace);
			  break;
		case 's': grace = (n > 2) ? (0) : (n * 4);
			  printf("%d",grace);
			  break;
		case 't': grace = (n > 1) ? (0) : (n * 5);
			  printf("%d",grace);
			  break;
	}

}
