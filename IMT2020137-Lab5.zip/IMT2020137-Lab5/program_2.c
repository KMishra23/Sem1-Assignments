#include <stdio.h>
#include <math.h>

int main() {
	int a, b, temp, sum, f = 0;
	scanf("%d %d",&a, &b);
	if(a < 0 || b < 0) printf("Invalid Input");
	else {

		while(a <= b) {//loop iterates through given range
			sum = 0;
			temp = a;
			while(temp > 0) {//loop checks each number if its an armstrong number
				sum = sum + pow((temp % 10),3);
				temp /= 10;	
			}	
			if(sum == a) {
				printf("%d\n",a);
				f = 1;//if f never turns 1 then there are no armstrong numbers between the given range
			}		
			a++;
		}	
		if(f == 0) printf("No Armstrong Number");

	}
}


