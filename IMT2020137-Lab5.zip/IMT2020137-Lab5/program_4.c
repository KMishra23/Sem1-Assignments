#include <stdio.h>

int main() {
	int n;
	char c;
	scanf("%d %c",&n,&c);
	if(n <= 0) printf("Invalid input");
	else {
		for(int i = 1; i <= 2*n - 1; i++) {//loop iterates from i = 1 to i = 2n - 1
			if(i <= n) {//this if part prints the upper half of the pattern
				for(int j = 1; j <= 2*i - 1; j++) {//this loop starts to iterate from 1 to 2i - 1 which eventually increases number of outputs
					printf("%c ",c);
				}
			}
			else {//this else part prints the lower half of the pattern
				for(int j = 1; j <= 2*(2*n-i)-1; j++) {//this loop iterates from 1 to (2n-i) - 1 which eventually decreases number of outputs
					printf("%c ",c);
				}
			}
			printf("\n");//new line at end of each line
		}
	}
}
