#include <stdio.h>

int main() {
	int n;
	scanf("%d",&n);
	int a, b, c, flag = 0;
	if(n <= 0) printf("Invalid Input");
	else{
		for(c = 1; c <= n; c++) {//loop first runs for the hypotenuse since order of output should increasing order for hypotenuse first
			for(b = 1; b <= n; b++) {//loop runs second for the longer of the other two sides
				for(a = 1; a <= n; a++) {
					if(a*a + b*b == c*c) {//condition to check for triplet
						if(a < b && b < c && a < c) {//condition to avoid repetitions so that a and b are never equal
							printf("%d %d %d\n",a,b,c);
							flag = 1;//if no triplet was found flag would stay 0 as an indicator
						}
					}	
				}
			}
		}
		if(flag == 0) printf("No triplet");
	}
}
