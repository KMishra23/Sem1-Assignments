n = int(input())
list = []
for i in range(0,n):#loop to fill list with n elements
    list.append(int(input()))
x = int(input())
y = int(input())
for i in range(0,n):#loop that checks foe each element in list if they are divisible by both x and y
    if(list[i] % x == 0 and list[i] % y == 0):
        print(list[i], end=' ')#if any number in the list satisfies the condition it is printed 

