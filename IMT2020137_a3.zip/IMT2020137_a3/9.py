n = int(input())
for i in range(3, 3*n + 1, 3):#loop starts from 3 since its the first positive number divisible by 3 and goes till 3*n + 1 so that i goes till 3*n
    print(i ** 2, end = ' ')
