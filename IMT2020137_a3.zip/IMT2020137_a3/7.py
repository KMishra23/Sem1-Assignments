n = int(input())
i = 1
while(i < 2*n + 1):#first n odd numbers will be till 2n+1 so we iterate from i = 0 to i = 2n-1
    print(i, end = ' ')
    i = i + 2#increment i by 2 since even numbers are to be skipped

