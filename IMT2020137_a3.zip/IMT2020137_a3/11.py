n = int(input())
i = 0
lst = []
while(i < n):#takes n inputs to the list
    lst.append(int(input()))
    i += 1
out = []
for a in lst:#a loop that iterates through each value in the loop
    if(a >= 18):
        out.append('Eligible')
    else:
        out.append('Not Eligible')
print(out)

