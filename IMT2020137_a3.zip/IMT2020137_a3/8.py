d1 = input().split(', ')#takes any number of inputs into d1 as a list separated by ', '(this is not a problem here since this code only reads the 1st three values)
d2 = input().split(', ')#same as d1
count = 2
for i in range(0, 3):#loop that iterates thrice to read dd/mm/yyyy but in reverse order 
    if(int(d1[count]) >int(d2[count])):#compares year, month and date in d1 and d2
        print('The date that occurs later is',d1)
        break#if the condition is saisfied then we break out of this loop since comparing other (for example month if year is greater) doesnt make sense
    elif(int(d1[count]) < int(d2[count])):
        print('The date that occurs later is',d2)
        break
    count = count - 1#count is decremented by one in each iteration so that we can move on from year to month and to date
if(d1 == d2): #checks if d1 and d2 list are equal or not 
    print('They are the same date')


