lst1 = input().split(', ')#takes input in lst1 with ', ' that are ignored 
lst2 = input().split(', ')
if(len(lst1) != len(lst2)):#checks if length of both lists is entered equal
    print("Invalid Input")
else:
    sum = []
    for i in range(0, len(lst1)):#loop that iterates length of the list times
        sum.append(int(lst1[i]) + int(lst2[i]))#appends the sum of ith term of both loops to a sum list

    print(sum)
