n = int(input())
for i in range(1,n+1):#first loop that indicates the row no.
    for j in range(1,i+1):#second loop that based on the row no. prints numbers = the current row no.
        print(j, end = ' ')
    print()#this print statement creates a newline at the end of each row
