n = int(input())
if(n % 2 == 0):#checks if n is even
    for i in range(1, n, 2):#prints each odd number multiplied by 3 in one line
        print(3*i, end=' ')
else:
    for i in range(0, n, 2):#prints each even number multiplied by 2 in one line
        print(2*i, end=' ')

