def hello(name):
    return ("Hello " + name)#returns name concatenated with "Hello"

if __name__ == "__main__":
    msg = hello(input())
    print(msg)
