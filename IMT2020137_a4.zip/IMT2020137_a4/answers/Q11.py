def mattrans(l):
    trans = [[l[i][j] for i in range(len(l))] for j in range(len(l[0]))]#this swaps the column element with row element and assigns them to another list by
                                                                        #by iterating through the list but assigning the elements in a reversed manner
    return trans

if __name__ == "__main__":
    print(mattrans([[1,2],[3,4]]))
