def balanced_brackets(m):
    lst = []
    for a in m:#looop to iterate through each char in m
        if a not in ['(',')','[',']','{','}']:#checks if a is a bracket or not if not then a is ignored entirely and loop moves on
            pass#used because if cant be empty
        elif(a == '(' or a == '{' or a == '['):#checks if a is one of the opening brackets
            lst.add(a)#adds a to the end of the lst 
        elif lst:#if lst has any element inside it program performs the following checks
            pop = lst.pop()#gets the the last element of lst to check if balanced is found
            if(pop == '('):#the following operations check if the coreect corresponding bracket to pop is found at a if not then returns False
                if (a != ')'):
                    return False
            elif(pop == '{'):
                if(a != '}'):
                    return False
            elif(pop == '['):
                if(a != ']'):
                    return False

    if lst:#if lst has any elements remaining then it must mean that brackets must have mismatched or excess opening brackets were found
        return False
    return True#if no element remains in lst then balanced brackets must be present(my program assumes that (}{) is not balanced nor is ({) since these dont match)

if __name__ == "__main__":
    print(balanced_brackets("[]"))
    print(balanced_brackets("][")) 
