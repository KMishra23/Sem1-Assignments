def matmul(m1,m2):
    if (len(m1) != len(m2[0])):#if number of columns of first matrix is != number of rows of second matrix then given matrices are not multicable
        msg = "Matrices are not multicable"
        return msg
    else:
        x = len(m1)
        pro = [[0 for a in range(x)]for b in range(x)]#creates a list pro with all elements 0 and of the dimensions that the product of m1 and m2 will have
        for i in range(len(m1)):#loop that iterates through the rows of m1
            for j in range(len(m2[0])):#loop that iterates through the columns of m2
                for k in range(len(m2)):#loop that one by one gets the value at m1 and m2 that need to be multiplied and added to the correct position in list pro
                    pro[i][j] = pro[i][j] + m1[i][k]*m2[k][j]
        return pro#required multipied matrix

if __name__ == "__main__":
    print(matmul([[1,2,3],[4,5,6]],[[7,10],[8,11],[9,12]]))

