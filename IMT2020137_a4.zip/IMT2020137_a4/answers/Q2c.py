def print_n_messages(m):
    for i in range(10):#loop to print message 10 times
        print(m)
if __name__ == "__main__":
    m = input()
    print_n_messages(m)
