def diamond(n, c):#same as Q4b but with * replaced by custom c
    i = 1
    count = 1
    a = 2
    while(n > 0):
        #number of stars in line will be i
        #number of spaces will be (n-i)/2
        k = int((n-i)/2)
        for j in range(k):
            print(' ',end='')
        for j in range(i):
            print(c,end='')
        print()
        if(count == n):
            break
        if(i == n):
            a = -2
        i = i + a
        count = count + 1

if __name__ == "__main__":
    n = int(input())
    c = input()
    diamond(n, c)

