def ndiamond(n):#same as Q5 but with custom n
    i = 1
    count = 1
    a = 2
    while(n > 0):
        #number of stars in line will be i
        #number of spaces will be (n-i)/2
        k = int((n-i)/2)
        for j in range(k):
            print(' ',end='')
        k = 1
        d = 1
        for j in range(i):
            print(k,end='')
            k = k + d
            if(k == int(i/2 + 1)):
                d = -1
        print()
        if(count == n):
            break
        if(i == n):
            a = -2
        i = i + a
        count = count + 1

if __name__ == "__main__":
    n = int(input())
    ndiamond(n)

