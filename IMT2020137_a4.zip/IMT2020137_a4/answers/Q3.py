def banner(m):
    for i in range(len(m) + 4):#loop prints top layer of stars
        print('*',end ='')
    print()
    print('*',m,'*')
    for i in range(len(m) + 4):#loop prints bottom layer of stars
        print('*',end ='')

if __name__ == "__main__":
    m = input()
    banner(m)
