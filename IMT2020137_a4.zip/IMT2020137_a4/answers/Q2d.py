def print_n_messages(m, n):
    for i in range(n):#loop that prints message n times
        print(m)

if __name__ == "__main__":
    m = input()
    n = int(input())
    print_n_messages(m, n)
