def print_n_messages():
    for i in range(10):#loop to print Hello World! 10 times
        print("Hello world!")

if __name__ == "__main__":
    print_n_messages()
