def diamond():
    n = 5
    i = 1
    count = 1#to count number of lines
    a = 2#incrementation of i
    while(n > 0):#infinite loop
        #number of stars in line will be i
        #number of spaces will be (n-i)/2
        k = int((n-i)/2)#had to typecast to int since it was giving error that float cannot be used in for loop
        for j in range(k):#loop to print spaces
            print(' ',end='')
        for j in range(i):#loop to print stars
            print('*',end='')
        print()#new line
        if(count == n):#the condition is checked inside loop so that the loop runs atleast once(for count = 1)
            break
        if(i == n):#i is incremented till it reaches n after which value of a is changed to -2 so that it reduces
            a = -2
        i = i + a#change to i
        count = count + 1#row number increased

if __name__ == "__main__":
    diamond()
