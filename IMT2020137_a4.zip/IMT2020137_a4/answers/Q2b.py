def print_n_messages(n):
    for i in range(n):#loop to print Hello World! n times
        print("Hello world!")

if __name__ == "__main__":
    n = int(input())
    print_n_messages(n)
