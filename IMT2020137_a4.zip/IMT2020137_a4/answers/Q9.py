def even_elements(l):
    return [i for i in l if i%2==0]#retains the elements in list that are divisible by 2

if __name__ == "__main__":
    lst = even_elements([0,1,2,3,4,5,6,7,8,9])
    print(lst)
