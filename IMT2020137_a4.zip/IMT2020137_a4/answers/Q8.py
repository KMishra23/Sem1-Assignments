def double(l):
    return [2*i for i in l]#list comprehension used to double all digits in list

if __name__ == "__main__":
    lst = double([1,2,3])
    print(lst)
