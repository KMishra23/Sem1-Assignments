#include <stdio.h>
#include <math.h>

int main()
{
	float x,f;
	scanf("%f",&x);//x is assigned the value which is tested for the root of the equation

	f = pow(x,4) - pow(x,3) - 24*pow(x,2) + 4*x +80;//x is put in the equation and the value is assigned to f

	if(f == 0) printf("Root");//if f == 0 then root is printed
	else if(f > 0) printf("Positive");//if f > 0 but not ==0 then Positive is printed
	else printf("Negative");// if f is not > 0 or == 0 then Negative is printed	
}
