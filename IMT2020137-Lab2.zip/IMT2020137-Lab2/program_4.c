#include<stdio.h>

int main(){
	int a, sum = 0 ;//sum is assigned the value 0 here so that in loop the first calculation using sum doesnt yield a trash value
	scanf("%d",&a);
	
	while(a > 0){//the loop only begins if the value of the entered number is > 0 since only then the number will have digits( if a = o then sum is already assigned 0 so the correct sum is printed in that case anyway)
		sum = sum +a%10;//divides the entered number by 0 and uses its remainder and adds it to varibale sum every time the loop is run
		a = a/10;//divides a by 10 so that the digit that was in ones place is discarded as it has already been used in calculation of sum and in the next iteration of the loop the digit in tens place can be used to add to sum till a == 0
	}
	printf("%d",sum);

}

