#include <stdio.h>
#include <math.h>

int main()
{
	int x,y;
	double val;
	scanf("%d %d",&x,&y);

	if(x>=y) val = log(y);//checks whether x is greater than or equal to  y and if its executes this line
	else val = exp(x);//if x is not greater than or equal to y executes this line

	printf("%.2f",val);
}

