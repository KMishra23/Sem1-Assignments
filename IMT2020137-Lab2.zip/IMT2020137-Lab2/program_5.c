#include <stdio.h>
#include <math.h>
int main(){
	double x,y,r,t;
	scanf("%lf %lf",&x, &y);
	r = pow((x*x+y*y),0.5);//calculation of x polar coordinate(r)
	t = atan(y/x);//calculation of y polar coordinate(t)
	printf("%.2lf %.2lf",r, t);
}
