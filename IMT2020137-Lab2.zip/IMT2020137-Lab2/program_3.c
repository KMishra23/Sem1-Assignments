#include <stdio.h>
#include <math.h>

int main()
{
	double a,b,c,D;
	scanf("%lf %lf %lf",&a,&b,&c);
	D = b*b - 4*a*c; // Discriminant of the quadratic equation
	if(a != 0){//checks whether if the vlaue of the coefficient of x^2 is not 0 if not then the following code is executed
		if (D < 0){//checks id Discriminant is less than 0 in which case roots are imaginary 
			double alp,beta1,beta2;
			alp = -1*b/(2*a);//calculation of real part of the roots
			beta1 = pow(-D,0.5)/(2*a);//calculation of imaginary part of one root
			beta2 = -1*pow(-D,0.5)/(2*a);//calculation of imaginary part of other root
			printf("%.2lf,%.2lf \n%.2lf,%.2lf",alp,beta1,alp,beta2);// prints the real and imaginary part of both roots			
		}
		else {// if discriminant is not < 0 then roots are real
			double r1,r2;
			r2 = (-b-pow(D,0.5))/(2*a);//calculation of first root
			r1 = (-b+pow(D,0.5))/(2*a);//calculation of second root
			printf("%.2lf \n%.2lf",r1,r2);//prints both real roots
		}	
	}
	else printf("Invalid input");//if coefficient of x^2 is 0 then invalid input is printed
}
