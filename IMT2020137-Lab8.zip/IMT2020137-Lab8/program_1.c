#include <stdio.h>
//flag keeps track of number of elements in the stack
int Push(int ele, int flag, int *stack) {
	if(flag == 5) {//checks if limit of stack is reached
		printf("STACK OVERFLOW");
		return -1;
	}
	else {
		*(stack+flag) = ele;//adds element to stack			
		return 0;
	}
	return 0;
}

int Pop(int *flag, int *stack) {
	if(*flag == 0) {//checks if stack is empty
		printf("STACK UNDERFLOW");
		return -1;
	}
	else {
		*flag -= 1;
		/* printf("Popped element = %d\n",*(stack+*flag)); */
		return *(stack+*flag);//after reducing nnumber of elements by one it returns the removed element
	}	
	return 0;
}

void Display(int flag, int* stack)  {
	if(flag == 0) {
		printf("STACK EMPTY");//checks for empty stack
	}
	else {
		for(int i = flag-1; i >= 0; i--) {
			printf("%d ",Pop(&flag,stack));//prints out the popped element
		}
	}
}

int main() {
	int a=1, flag = 0, stack[5], ele, check = 0;
	char in;
	while(a) {//infinite loop
		scanf("%c",&in);
		switch(in) {
		case 'c' : 
			Display(flag,stack);
			return 0;//program terminates for c
		case 'a' :
			scanf("%d",&ele);
			check = Push(ele,flag,stack);
			if(check == -1) return 0;//program terminates for overflow
			flag++;
			break;
		case 'b' :
			check = Pop(&flag,stack);
			if(check == -1) return 0;//program terminates for underflow
			break;
		}
	}
}
