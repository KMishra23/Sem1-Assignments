#include <stdio.h>

int* sort(int arr[], int len) {//sorts given array and its length and returns the sorted array pointer
	int k = 0,count = 1, temp;
	/*Picks elements one by one and compares them to each element before it till it finds an element larger than it and exchanges their places again and again till it is in the right position*/
	while(count < len) {
		for(int i = 0; i < count; i++) {
			if(arr[i] > arr[count]) {
				temp = arr[i];
				arr[i] = arr[count];
				arr[count] = temp;
			}
		}
		count++;
	}
	return arr;
}

int* combine(int Asize, int A[], int Bsize, int B[]) {
    A = sort(A,Asize);
    B = sort(B,Bsize);//sprting both A and B
    int a = 0,b = 0;
    int c[Asize+Bsize];//making an array c of size of A + B
    for(int i = 0; i < Asize+Bsize; i++) {//compares elements of sorted A and B one by one and keeps placing them in c
	if(a == Asize) {
		c[i] = B[b];
		b++;
	}
	else if(b == Bsize) {
		c[i] = A[a];
		a++;
	}
	else if(A[a] < B[b]) {
		c[i] = A[a];
		a++;
	}
	else {
		c[i] = B[b];
		b++;
	}
    }
    for(int i = 0; i < Asize+Bsize; i++) {
	    printf("%d ",c[i]);
    }
    return c;//returns array pointer of combined array c
}

int main() {
    int a,b;
    scanf("%d",&a);
    int A[a];
    for(int i = 0; i < a; i++) {
        scanf("%d",&A[i]);
    }
    scanf("%d",&b);
    int B[b];
    for(int i = 0; i < b; i++) {
        scanf("%d",&B[i]);
    }
    int *c = combine(a,A,b,B);
}
