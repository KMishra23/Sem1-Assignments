#include <stdio.h>
int* rotate(int arr[], int len) {//rotates a given one dimensional array once
	int temp = arr[0];
	for(int i = 1; i < len; i++) {//elements are moved to the left
		arr[i-1] = arr[i];
	}
	arr[len-1] = temp;
	return arr;
}
void print_rotate(int r, int m, int n) {//prints the row after required rotations
	int arr[n];
	int *narr;//new rotated row
	for(int i = 0; i < n; i++) {//creates required row
		arr[i] = m+i;
	}
	for(int i = 0; i < r; i++) {//rotates row required number of times
		narr = rotate(arr, n);
	}
	for(int i = 0; i < n; i++) {//prints out the row
		printf("%d ",arr[i]);
	}
}
int main() {
	int m, n, rot;
	scanf("%d %d",&m,&n);
	for(int i = 0; i < m; i++) {
		scanf("%d",&rot);
		print_rotate(rot, i, n);
		printf("\n");
	}
}
