#include <stdio.h>
void mul_matrices(int *a, int *b, int m1, int n1, int m2, int n2) {//takes all pointers to both matrices and all their dimensions
	int res[m1][n2], sum;
	for(int i = 0; i < m1; i++) {
		for(int j = 0; j < n2; j++) {
			sum = 0;//used this for clarity and debugging
			for(int k = 0; k < m2; k++) {
				sum += (*(a+k+i*n1))*(*(b+j+n2*k));//applying required operation to get multiplied matrix element
			}
			res[i][j] = sum;
		}
	}
	for(int i = 0; i < m1; i++) {//prints out the final matrix
		for(int j = 0; j < n2; j++) {
			printf("%d ",res[i][j]);
		}
		printf("\n");
	}
}

int main() {
	int m1,m2,n1,n2;
	scanf("%d %d %d %d",&m1,&n1,&m2,&n2);
	int a[m1][n1], b[m2][n2];
	for(int i = 0; i < m1; i++) {
		for(int j = 0; j < n1; j++) {
			scanf("%d",&a[i][j]);
		}
	}
	for(int i = 0; i < m2; i++) {
        	for(int j = 0; j < n2; j++) {
                	scanf("%d",&b[i][j]);
                }
        }
	if(n1 != m2) printf("NOT POSSIBLE");//if number of columns of 1st matrix is != number of rows of 2nd matrix then multiplication is impossible
	else {
		mul_matrices((int *)a,(int *)b,m1,n1,m2,n2);
	}
}
