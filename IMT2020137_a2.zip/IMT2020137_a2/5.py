a = int(input())
b = int(input())
c = int(input())
if(a >= b and a >= c): ##Checks if a is greater than or equal to b and c 
    print("Largest Number:",a)
elif(b >= c): ##if above statement was false then cheecks if b is greater than or equal to c
    print("Largest Number:",b)
else: ##Since both above failed c has to be the greatest number
    print("Largest Number:",c)
