n = int(input())
if(n % 3 == 0 and n % 5 == 0): ##Checks if number s divisible by both 3 and 5
    print('FizzBuzz')
elif(n % 3 == 0): ##Checks if number is divisible by only 3
    print('Fizz')
elif(n % 5 == 0): ##Checks if number is divisible by only 5
    print('Buzz')
else:##If all above failed then number is neither divisible by 3 nor by 5
    print(n)
