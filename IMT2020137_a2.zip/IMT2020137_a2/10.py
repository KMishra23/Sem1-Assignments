c = int(input())
a = int(input())
if(a/c < 0.75): ##Checks if the quotient of division of the two numbers is less than 0.75 ie if attendance is less than 75%
    print('Not Allowed')
else:
    print('Allowed')
