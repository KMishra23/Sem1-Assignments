x = int(input())
if(x < 25): ##Checks if x < 25
    print('F')
elif(x >= 25 and x < 45): ##Checks if x >= 25 and x < 45 if the above condition was false
    print('E')
elif(x >= 45 and x < 50): ##Similar to above comparision
    print('D')
elif(x >= 50 and x < 60):
    print('C')
elif(x >= 60 and x < 80):
    print('B')
else:
    print('A')
