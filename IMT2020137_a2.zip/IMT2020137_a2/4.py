n = int(input())
if(n % 2 == 0):##checks if division by 2 gives remainder 0 in which case number will be even
    print(n,'is even');
else:
    print(n,'is odd')
