print(len(input())) ##takes the input string calculates it's length and outputs its value
