if(int(input()) == int(input())): ##Takes two inputs and compares them and prints yes if inputs are equal hence it is a square else false
    print('Yes')
else:
    print('No')
