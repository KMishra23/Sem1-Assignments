#include <stdio.h>

struct student {
	int roll;
	char name[500];
	int 
};
