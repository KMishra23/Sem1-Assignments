#include <stdio.h>

int main() {
	int n, num, zero, one;
	scanf("%d",&n);
	for(int i = 0; i < n; i++) {
		zero = 0;
		one = 0;
		scanf("%d",&num);
		while(num) {
			if(num%10 == 1) one++;
			else zero++;
			num /= 10;
		}
		if(one == zero) printf("True\n");
		else printf("False\n");
	}
}
