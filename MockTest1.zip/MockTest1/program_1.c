#include <stdio.h>

int main() {
	int n, min, hrs, temp;
	scanf("%d",&n);
	for(int i = 0; i < n; i++) {
		scanf("%d",&min);
		temp = min%60;
		hrs = min/60;
		printf("%d:%d\n",hrs,temp);
	}
}
