#include <stdio.h>

int main()
{
	int a,b,quo,rem; //Declaration of variables
	scanf("%i %i",&a,&b);// User input to a and b
	quo = a/b; //Quotient calculation
	rem = a%b; // Remainder calculation
	printf("%i %i",rem,quo); //  Output of obtained quotient and remainder values
}
