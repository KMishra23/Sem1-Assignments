#include <stdio.h>

int main(){
	int n;//Declaration of variable n 
	float avg;//Declaration of variable avg used to store the required value ie. average of the squares of n natural numbers
	scanf("%i",&n);//Input of n
	avg = (n+1)*(2*n+1)/6.0;//Caluclation of avg of sum of squares till n
	printf("%.2f",avg);//Required value of avg is printed 	
}
