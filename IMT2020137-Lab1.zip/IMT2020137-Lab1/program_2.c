#include <stdio.h>
int main(){
	float a,b,c,arr,per,arc,pec; //Variable Declaration
	scanf("%f %f %f",&a, &b, &c); //User input to variables
	arr = a*b;//Area of rectangle
	per = 2*(a+b);//Perimeter of rectangle
	arc = 3.14*c*c;// area of circle
	pec = 3.14*2*c;// circumference
	printf("%.2f %.2f %.2f %.2f",arr,per,arc,pec);//Output of calculated values
}
