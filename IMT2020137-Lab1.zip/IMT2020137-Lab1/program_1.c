#include <stdio.h>
int main(){
        float cel, faren; //Variable declaration
        scanf("%f", &cel); //Input of value in celsius
        faren = cel*9/5+32; //Conversion step
        printf("%.2f", faren); //The calculated value of temperature in farenheit is printed
}  
