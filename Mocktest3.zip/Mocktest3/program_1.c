#include <stdio.h>

int main() {
	int t,n,area;
	scanf("%d",&t);
	for(int i = 0; i < t; i++) {
		scanf("%d",&n);
		n = (n%2 == 0) ? (n/2) : ((n-1)/2);
		if(n % 2 == 0) {
			printf("%d\n",(n*n/4));
		}
		else {
			printf("%d\n",(n+1)*(n-1)/4);
		}
	}
}
