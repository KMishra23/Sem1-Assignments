#include <stdio.h>

int main() {
	int t,n,temp,max;
	scanf("%d",&t);
	for(int i = 0; i < t; i++) {
		scanf("%d",&n);
		int arr[n];
		for(int j = 0; j < 2*n; j++) {
			if(j < n) {
				scanf("%d",&temp);
				arr[j] = 3*temp;
			}	
			else {
				scanf("%d",&temp);
				arr[j - n] += temp;
			}	
		}
		max = arr[0];
		for(int j = 1; j < n; j++) {
			max = (max >= arr[j]) ? (max) : (arr[j]);
		}
		printf("%d\n",max);
	}
}
