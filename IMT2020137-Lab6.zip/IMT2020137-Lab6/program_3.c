#include <stdio.h>
#include <math.h>

double distance(double x1, double y1, double x2, double y2) {//calculates distance between two points 
	double dist = sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
	return dist;
}

double area(double x1, double y1, double x2, double y2, double x3, double y3) {//calculates area of triangle with 3 given coords using heron's formula
	double area;
	double a = distance(x1,y1,x2,y2);
	double b = distance(x2,y2,x3,y3);
	double c = distance(x3,y3,x1,y1);
	double s = (a + b + c)/2;
	area = sqrt(s*(s-a)*(s-b)*(s-c));
	return area;
}

void check(double x, double y, double x1, double y1, double x2, double y2, double x3, double y3) {//checks if given point lies inside a given triangle
	float a1 = area(x,y,x2,y2,x3,y3);//I had to use float here since using double wasnt always returning the correct answer
	float a2 = area(x,y,x1,y1,x2,y2);//I dont know the exact reason but i thought it might be because double has more decimal precision and my program uses sqrt
	float a3 = area(x,y,x1,y1,x3,y3);//the last few decimal points might differ in using double but not while using float
	float a = area(x1,y1,x2,y2,x3,y3);
	if(a == (a1 + a2 + a3)) printf("INSIDE\n");
	else printf("OUTSIDE\n");
}

int main() {
	double x1,y1,x2,y2,x3,y3;
	scanf("%lf %lf %lf %lf %lf %lf",&x1,&y1,&x2,&y2,&x3,&y3);
	double arr = area(x1,y1,x2,y2,x3,y3);
	printf("%.6lf\n",arr);//area printed till  decimal places
	int n;
	scanf("%d",&n);
	for(int i = 0; i < n; i++) {//loop that checks if points entered are inside or outside one by one
		double xtemp, ytemp;
		scanf("%lf %lf",&xtemp,&ytemp);
		check(xtemp,ytemp,x1,y1,x2,y2,x3,y3);
	}
}
