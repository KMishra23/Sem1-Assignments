#include <stdio.h>

double pow(double n, int power) {//calculates exponents
	double exp = n;
	for(int i = 1; i < power; i++) {//multiples exp by n, power times
		exp *= n;
	}
	return exp;
}	

int fac(int n) {//calculates factorial
	int factorial = 2;
	for(int i = 3; i <= n; i++) {//multiplies factorial by increasing values till n 
		factorial *= i;
	}
	return factorial;
}

int main() {
	double n, sin;
	scanf("%lf",&n);
	sin = n;
	int a = 1;
	for(int i = 3; i <= 11; i += 2) {//calculates the required expansion of sinx till the 6th term
		sin += pow(-1, a) * (pow(n, i) / fac(i));
		a++;
	}
	printf("%.6lf",sin);//prints value till 6 decimal places
}
