#include <stdio.h>
#include <math.h>

void binom(int n, int r) {
    int count = 1;//this variable will store the final value of binomial coeff
    int j = 1;//j usage explained in loop
    int a = (n/2 >= r) ? (n-r) : (r);//a is assigned the larger of the two values r and n-r so that we can efficiently skip a larger portion of the calc always
    for(int i = a + 1; i <= n; i++) {//loop starts from a+1 since I before starting my calculation removed a! from denominator and reduced the numerator accordingly
        count = count * i;//count starts loop by being multiplied by i all the way till n
        while(j > 0 && j <= (n-a)){//this loop is only used till j hits its max value of n-a
            if(j <= (n-a) && count % j == 0) {//count is divided by j only if it is divisible by it(dont to avoid decimal place errors and overflow)
                count = count / j;
                j++;//j is divided by count until it either reached n-a or count is more divisible by it
            }
            else break;//breaks if conditions not satisfied
        }
    }
    printf("%d",count);
}

int main() {
    int n, r;
    scanf("%d %d",&n,&r);
    binom(n,r);
}
