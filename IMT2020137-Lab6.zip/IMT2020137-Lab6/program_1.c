#include <stdio.h>

void prime_fac(int n) {
	int fac = 2;
	while(fac <= n) {
		if(n % fac == 0) {//if n is divisible by fac then it keeps dividing n by fac until it is not
			printf("%d ",fac);
			n /= fac;
		}
		else fac++;//if fac is not divisible by n then increments by 1(Could have done by 2 and checked for 2 in the beginning as well)
	}
}

int main() {
	int n;
	scanf("%d",&n);
	prime_fac(n);
}
