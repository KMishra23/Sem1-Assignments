#include <stdio.h>

int main() {
	int a;
	scanf("%d",&a);
	float n, p, temp;
	for(int i = 0; i < a; i++) {
		scanf("%f",&n);
		p = 0;
		temp = 0;
		while(n > 0) {
			scanf("%f",&temp);
			if(temp == -1) break;
			else {
				p += temp;
			}
		}
		p = 1.18*p;
		if(p < n) printf("ENOUGH MONEY\n");
                else printf("$%.2f SHORT\n",(p - n));
	}
}
