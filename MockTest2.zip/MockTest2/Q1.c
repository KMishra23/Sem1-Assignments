#include <stdio.h>
int prime(int n) {
	for(int i = 2; i < n; i++) {
		if(n % i == 0) {
			return 0;
		}
	}
	return 1;
}
int main() {
	int t,x,y,sum;
	scanf("%d",&t);
	for(int i = 0; i < t; i++) {
		scanf("%d %d",&x,&y);
		sum = x+y;
		if(sum == 2) printf("1\n");
		else{
			int c = sum;
			if(prime(sum) == 1) {
				sum++;
				while(prime(sum) != 1) {
					sum ++;
				}
				printf("%d\n",sum - c);
			}
			else{
				while(prime(sum) != 1) {
					sum++;
				}
				printf("%d\n",sum - c);
			}
		}
		
	}
}
