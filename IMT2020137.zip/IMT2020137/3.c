#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int sum = 2;
	int s0 = 1, s1 = 1, si;
	for(int i = 0; i < n-2; i++) {
		si = s1 + s0 * s0;
		sum += si*si*si;
		s0 = s1;
		s1 = si;
	}
	printf("%d",sum);
}
