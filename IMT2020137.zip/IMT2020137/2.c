#include <stdio.h>
#include <math.h>

int main() {
	int a, b, temp1, temp2;
	scanf("%d %d",&a, &b);
	temp1 = a;
	temp2 = b;
	while(temp1 != 0 || temp2 != 0) {
		if(temp1 % 10 != 1 && temp1 % 10 != 2 && temp1 % 10 != 0) {
			printf("Invald Input");
			return 0;
		}
		else if(temp2 % 10 != 1 && temp2 % 10 != 2 && temp2 % 10 != 0) {
			printf("Invalid Input");
			return 0;
		}
		else {
			temp1 /= 10;
			temp2 /= 10;
		}
	}
	int deca = 0, decb = 0;
	int power = 0;
	while(a > 0) {
		deca += (a%10)*pow(3,power);
		a /= 10;
		power ++;
	}
	power = 0;
	while(b > 0) {
		decb += (b%10)*pow(3,power);
		b/= 10;
		power ++;
	}
	int sum = deca + decb;
	int sumb3 = 0;
	int count = 0;
	while(sum > 0) {
		sumb3 += pow(10,count)*(sum%3);
		sum /= 3;
		count ++;
	}
	printf("%d",sumb3);

}

