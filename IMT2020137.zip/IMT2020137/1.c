#include <stdio.h>

int main() {
	int n;
	scanf("%d",&n);
	if(n % 5 != 0) printf("No such divisors");
	else {
		for(int i = 5; i < n; i = i + 5) {
			if(n % i == 0) {
				printf("%d ",i);
			}
		}
	}
}
