#include <stdio.h>

int main() {
	int n;
	scanf("%d",&n);
	int p, q, min = -1;
	for(int i = 2; i < n/2; i++) {
		if(n % i == 0 && min == -1){
			q = i;
			p = n/q;
			min = p - q;	
		}
		else if(n % i == 0) {
			int check = (i > n/i) ? (i - n/i) : (n/i - i); 
			if(min > check) {
				min = check;
				q = i;
				p = n/q;	
			}
		}
	}
	if(p != q) {
		for(int i = p; i >= 1; i--) {
			int count = p - i;
			for(int tri = 1; tri <= q; tri++) {
				for(int k = 0; k < count; k++) {
					printf("  "); 
				}	
				for(int j = 1; j <= i; j++) {
					printf("* ");
				}
			}
			printf("\n");
		}
	}
}
