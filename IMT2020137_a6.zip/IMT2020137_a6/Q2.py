user_db = {"user_1": "pwd_11","user_2": "pwd_21","user_3": "pwd_31","user_4": "pwd\\n1234","user_5": "$pwd#12$"}

def validate_user(uname):
    if uname in user_db.keys():
        return True
    else:
        return False

def check_password(uname, pwd):
    if(user_db[uname] == pwd):
        return True
    else:
        return False

def authenticate_user(uname, pwd):
    if validate_user(uname):
        if check_password(uname, pwd):
            print("User Authenticated")
            return 0
        print("Incorrect Password")
        return 0
    print("Username Does Not Exist")
    return 0

if __name__ == "__main__":
    authenticate_user("user1", "pwd_11")
    authenticate_user("user_1", "pwd_123")
    authenticate_user("user_4", "pwd\\n1234")
    

    
