count = 1
lst = [0,1,1]
def pascal_triangle(n):
    global count
    global lst
    if(n == 0):
        count = 1
        lst.clear()
        lst = [0,1,1]
        return 
    else:
        if(count == 1):
            print("1")
            count = count + 1
            n = n - 1
            pascal_triangle(n)
        elif(count == 2):
            print("1 1")
            count = count + 1
            n = n - 1
            pascal_triangle(n)
        else:
            nlst = []
            a = 1
            t = 0
            for i in range(count):
                if(t == 0):
                    print("1", end=' ')
                    nlst.append(1)
                    t = 1
                elif(a == count-1):
                    print('1', end=' ')
                    nlst.append(1)
                else:
                    num = lst[a] + lst[a+1]
                    print(num, end=' ')
                    nlst.append(num)
                    a = a + 1
            print()
            lst.clear()
            lst = nlst
            lst.insert(0,0)
            count = count + 1
            n = n - 1
            pascal_triangle(n)

if __name__ == "__main__":
    pascal_triangle(5)
