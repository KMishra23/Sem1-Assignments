lst = [1,2,3,4,5,6]
print(lst[0])
print(lst[0:1])
