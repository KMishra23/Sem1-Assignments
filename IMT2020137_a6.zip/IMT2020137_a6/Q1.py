import math
def dot_product(A, B):
    if(len(A) < 3):
        count = len(A)-1
        while(count < 3):
            A.append(0)
            count = count + 1
    if(len(B) < 3):
        count = len(B)
        while(count < 3):
            B.append(0)
            count = count + 1
    dot = A[0]*B[0]
    dot = dot + A[1]*B[1]
    dot = dot + A[2]*B[2]
    return dot

def magnitude(A):
    i = len(A)-1
    mag = 0
    while(i >= 0):
        mag = mag + A[i]**2
        i = i - 1
    mag = mag**0.5
    return mag

def cross_product(A, B):
    cos = dot_product(A,B)/(magnitude(A)*magnitude(B))
    sin = (1-(cos**2))**0.5
    cross = sin * magnitude(A) * magnitude(B)
    return round(cross,2)

if __name__ == "__main__":
    print(cross_product([1,2,3],[4,5,6]))
    
