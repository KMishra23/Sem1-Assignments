def find_nth_element(n, lst):
    if(n == 0):
        return lst.pop(0)
    else:
        lst.pop(0)
        return find_nth_element(n-1, lst)

if __name__ == "__main__":
    print(find_nth_element(3, [1,2.0,6,9,'cs','ece']))
