def find_len(lst):
    if(lst):
        return (1 + find_len(lst[1:]))
    else:
        return 0

if __name__ == "__main__":
    lst = [1,2,3,4,5]
    print(find_len(lst))
    
