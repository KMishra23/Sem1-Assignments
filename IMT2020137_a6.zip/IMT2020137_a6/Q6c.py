def reverse_list(lst, a = 0):
    if(a == int(len(lst)/2)):
        return lst
    else:
        lst[a],lst[len(lst)-a-1] = lst[len(lst)-a-1],lst[a]
        return (reverse_list(lst, a+1))

if __name__ == "__main__":
    print(reverse_list([1,2,6.6,'python']))
