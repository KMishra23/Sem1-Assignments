def power(n, p):
    if(p == 0):
        return 0
    elif(p == 1):
        return n
    else:
        p = p - 1
        return(n*power(n, p))

if __name__ == "__main__":
    print(power(2,3))

