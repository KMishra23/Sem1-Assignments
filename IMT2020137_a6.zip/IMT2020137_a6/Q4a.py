def total_sum(lst):
    sum = 0
    for i in range(len(lst)):
        if(type(lst[i]) == int or type(lst[i]) == float):
            sum = sum + lst[i]
        elif(type(lst[i]) == list):
            sum = sum + total_sum(lst[i])
    return sum

print(total_sum([[1,2.5,3],[4,['abc',6]],7]))
