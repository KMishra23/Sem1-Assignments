def find_len(lst):
    if(lst):
        return (1 + find_len(lst[1:]))
    else:
        return 0

def find_nth_element(n, lst):
    if(n == 0):
        return lst.pop(0)
    else:
        lst.pop(0)
        return find_nth_element(n-1, lst)

def reverse_list(lst, a = 0):
    if(a == int(len(lst)/2)):
        return lst
    else:
        lst[a],lst[len(lst)-a-1] = lst[len(lst)-a-1],lst[a]
        return (reverse_list(lst, a+1))

if __name__ == "__main__":
    print(find_len([1, 2.0, 6, 'xyz', 15]))
    print(find_nth_element(3, [1, 2.0, 6, 9, "cs", "ece"]))
    print(reverse_list([1, 2, 6.6, "python", 15]))
