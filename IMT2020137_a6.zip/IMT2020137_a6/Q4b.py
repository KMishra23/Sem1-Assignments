def flatten(lst):
    nlst = []
    for i in lst:
        if(type(i) == list):
            for a in i:
                nlst.append(a)
        else:
            nlst.append(i)
        if(len(lst) == 1):
            return lst
    return (flatten(nlst[0:1]) + flatten(nlst[1:]))


if __name__ == "__main__":
    print(flatten([[2,[8,9]],[10,11,'iiitb'],[13]]))
