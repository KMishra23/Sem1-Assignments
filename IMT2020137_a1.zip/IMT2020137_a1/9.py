print("n = ")
n = float(input())
print("a.",round(n),"\nb.",round(n+1))
