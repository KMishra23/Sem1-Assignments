i = int(input())
print(0.621 * i,"miles")
