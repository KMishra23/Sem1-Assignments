print("a = ",)
a = int(input())
print("b = ",)
b = int(input())
a,b = b,a
print('a = ',a)
print('b = ',b)

print('x = ')
x = int(input())
print('y = ')
y = int(input())
temp = x
x = y
y = temp
print('x = ',x)
print('y = ',y)


