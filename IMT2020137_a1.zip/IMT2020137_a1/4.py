x = int(input())
area = x*x
dia = pow(2,0.5)*x
peri = 4*x
print('Diagonal length = ',round(dia,2), '\nPerimeter = ', peri, '\nArea = ',area)

