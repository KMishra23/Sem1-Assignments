n = int(input())
print(n + (n*n) + (n*n*n))
