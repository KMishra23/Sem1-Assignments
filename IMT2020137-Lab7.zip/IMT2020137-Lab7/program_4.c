#include <stdio.h>
#include <math.h>

void moves(int);

int main() {
	int n;
	scanf("%d",&n);
	moves(n);
}

void moves(int n) {//minimum number of moves to move the discs to peg C will be 2^n - 1
	int moves = pow(2, n) - 1;
	printf("%d",moves);
}
