#include <stdio.h>

int gcd(int, int);

int main() {
	int a,b,temp;
	scanf("%d %d",&a,&b);
	if(b >= a) {//this makes it so that a is larger of the two
		temp = a;
		a = b;
		b = temp;
	}
	printf("%d",gcd(a,b));
}

int gcd(int a, int b) {
	if(a % b == 0) return b;//exit case for recursion
	else {//recursion
		return gcd(b, a%b);//this is using gcd(a,b) = gcd(b,a%b)
	}
}

