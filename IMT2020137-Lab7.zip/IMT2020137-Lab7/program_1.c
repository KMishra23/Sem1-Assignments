#include <stdio.h>
#include <math.h>
//this program instead of getting the solution at once also shows the exact move each player makes at their turn.
//in each iteration of the recursive loop we can check the value of n to know how many coins the player picked  
void game(int n, int id){
	if(n == 1 || n == 2) {//to exit the recursive loop this is the condition
		if(id % 2 == 0) printf("Ravi");
		else printf("Rinku");
	}
	else if(n % 3 != 0) {//the player that has to move any value of n not divisible by 3 knows he will always win. But to winn he will have to pick coins
			     //such that the opponent is left to choose from n%3==0 coins.	
		if(n % 3 == 1) {//this if else checks if the winner should pick either 1 or 2 coins to win
			n--;
			id++;//id is increased to pass the turn(odd id indicates that rinku is playing and even is ravi)
			game(n, id);//recursion		
		}
		else {
			n -= 2;
			id++;
			game(n ,id);	
		}
	}
	else {//the person that has to play at n%3==0 knows they will lose so they will try to finish the game as quickly as possible. They will do so by picking
	      //the power of 2 closest to n			
		int temp = n, count = 0;//count counts the number of bits in n
		while (temp) {//this loop calculates the number of bits in n. I use this to calculate the closest power of 2 less than n(saw this code during viva)
			count += temp & 1;
			temp >>= 1;
		}
		n -= pow(2, count - 1);//n is deducted by the largest possible value(since the loser wants to end the game as quick as possible)
		id++;
		game(n, id);
	}
}

int main() {
	int n, id;
	scanf("%d %d",&n,&id);
	game(n ,id);
}
