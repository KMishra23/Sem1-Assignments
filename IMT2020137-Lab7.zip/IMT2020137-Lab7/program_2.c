#include <stdio.h>
#include <math.h>

int is_palindrome(int);
int n;//global variable to store value of number for later comparision

int main() {
	scanf("%d",&n);
	int k = is_palindrome(n);
	if(k == 1) printf("Yes");
	else printf("No");
}

int is_palindrome(int x) {
	static int rev = 0;//static int used because rev needs to retain its value everytime function is called for recursion
	if(x) {//recursive loop to store reverse of n in rev
		rev = 10*rev + x%10;
		return is_palindrome(x/10);
	}
	else if(rev == n) {
		return 1;
	}
	return 0;
}
