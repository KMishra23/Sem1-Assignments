#include <stdio.h>

int main() {
	int r, g, b;//red green blue
	scanf("%d %d %d",&r, &g, &b);
	float w, c, m, y, k;//white cyan magenta yellow black
	if(r >= g && r >= b) w = r/255.0;//checks if red is the laregst among rgb and assigns white = red/255 if its true(if rgb are equal then white = red/255
	else if (g >= b) w = g/255.0;//checks if green is larger than blue and assigns white = green/255
	else w = b/255.0;//now blue has to be largest if above two conditions fail and assigns white = blue/255

	if(r == b && r == g){//for condition where r==g==b we can see through formula that cmy will always be 0 and k will be white - 1
		c = 0;
		m = 0;
		y = 0;
		k = 1 - w;
		printf("%.2f %.2f %.2f %.2f",c,m,y,k);
	}

	else{//if rgb are unequal then the following formulae are used to calculate cmyk and printed
		c = (w - r/255.0)/w;
		m = (w - g/255.0)/w;
		y = (w - b/255.0)/w;
		k = 1 - w;
		printf("%.2f %.2f %.2f %.2f",c,m,y,k);
	}	

}
