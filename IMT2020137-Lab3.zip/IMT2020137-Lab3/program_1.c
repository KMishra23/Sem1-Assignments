#include <stdio.h>
#include <math.h>

int main() {
	int x1,x2,r1,r2,y1,y2;
	scanf("%d %d %d %d %d %d",&x1,&y1,&r1,&x2,&y2,&r2);
	int dist = pow(pow((x1-x2),2) + pow((y1-y2),2),0.5); // Calculation of distance between the centres of the two circles
	int rsum = r1 + r2;//sum of radius of the two circles
	
	if(r1 < 0 || r2 < 0) printf("Invalid Input"); //Checks whether if radius of any is negative
	
	else{
		if(dist == rsum) printf("Touch");//if dist between centres == sum of radii then circles touch
		else if(dist < rsum) printf("Intersect");//if dist between centres is less sum of radii then the circles intersect
		else printf("No Intersection");//if both conditions above fail then the circles dont intersect
	}
}

