#include <stdio.h>
#include <math.h>

int main() {
	int x1, y1, x2, y2, x3, y3;
	scanf("%d %d %d %d %d %d",&x1, &y1, &x2, &y2, &x3, &y3);
	int a = pow(pow(x1 - x2,2) + pow(y1 - y2,2), 0.5);//calculation of side lengths and assigning them to variables a b and c
       	int b = pow(pow(x1 - x3,2) + pow(y1 - y3,2), 0.5);
	int c = pow(pow(x2 - x3,2) + pow(y2 - y3,2), 0.5);
	
	if((a + b == c) || (a + c == b) || (b + c == a)) printf("Not Triangle");//checks if the sum of sides of any two sides is equal to the other one
										//in which case the given points wouldn't form a triangle
	else{
		if(a == b && a == c) printf("Equilateral");//checks whether if sides are equal
		else if((a != b) && (a == c || b == c)) printf("Isosceles");//checks first if the first two sides are unequal and one of the unequal sides
        	else if((a != c) && (a == b || c == b)) printf("Isosceles");//is equal to the last one in all the else if statements one by one
		else if((b != c) && (a == b || a == c))	printf("Isosceles");
		else printf("Scalene");//if the above conditions fail triangle has to be scalene
	}
}
