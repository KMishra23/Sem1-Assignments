#include <stdio.h>

int main() {
	int h, t;//hardness and tensile strength
	float c;//carbon content
	scanf("%d %f %d",&h,&c,&t);
	if((h > 50) && (c < 0.7) && (t > 5600)) printf("10");//using given parameters in question grade of steel is assigned by comparing
	else if((h > 50) && (c < 0.7)) printf("9");          //hardness, carbon content and tensile strength. 
	else if((c < 0.7) && (t > 5600)) printf("8");
	else if((h > 50) && (t > 5600)) printf("7");
	else if((h > 50) || (c < 0.7) || (t > 5600)) printf("6");
	else printf("5");

}
