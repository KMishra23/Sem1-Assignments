#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d",&n);
	if(n < 0) printf("Invalid input");//checks if n < 0
	else {
		int oct = 0, count = 0;//assigns octal of n = 0 and counter 0
		while(n != 0){//loop runs as long as n is not 0
			oct += pow(10,count)*(n%8);//remainder of n/8 is multiplied by 10 raised to count and added to oct
			n /= 8;	//n is divided by 8 to remove last octal digit
			count++;//count is incremented by 1 each iteration so that the next ocatl digit is added to the next place		
		}
		printf("%d",oct);
	}
}
