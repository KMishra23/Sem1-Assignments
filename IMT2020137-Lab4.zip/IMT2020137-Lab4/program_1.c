#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d",&n);
	int max, min, temp;
	if(n > 0) {//checks if n > 0
		for(int i = 0; i < n; i++) {//loop to take n inputs
			scanf("%d",&temp);
			if(i == 0) {//for the first iteration of this loop the value of both max and min have to be the first input since neither have any value
				max = temp;
				min = temp;
			}
			else{//in later iterations of this loop value of max and min are compared and assigned appropriately using ternary operators
				max = (temp > max) ? (temp) : (max);
				min = (temp < min) ? (temp) : (min);
			}
		}
		printf("%d",(max - min));//prints range = max - min
	}
	else printf("Invalid input");
}
