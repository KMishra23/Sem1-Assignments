#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d",&n);
	if(n < 0) printf("Invalid input");//checks if n < 0
	else{
		int temp = n;
		int num_dgts = 0;
		while(n > 0){//this loop is infinite and it counts the number of digits in n it divides temp by 10 till temp == 0 after which the loop breaks
			temp /= 10;
			num_dgts ++;//in each iteration num_dgts is incremented by 1 starting from 0
			if(temp == 0) break;	
		}
		int inv = 0;//inverse number is assigned 0
		int digit;
		temp = num_dgts;//temp is assigned num_dgts so that we can use it to make inverse
		for(int i = 0; i < num_dgts; i++) {//this loop is iterated num_dgts times
			digit = n % 10;//last digit is extracted from n
			n /= 10;//n is divided by 10 to remove the extracted digit
			inv += digit * pow(10,(temp - 1));//the digit times 10 raised to temp - 1 is added to inv(in the 1st run the last digit*10^highest power in 
		     					//the number is added, in the 2nd run  the 2nd last digit*10^2nd highest power in the number is added and so on 	
			temp --;//temp is decremented by 1 at the end of each iteration
		}
		printf("%d",inv);
	}
}
