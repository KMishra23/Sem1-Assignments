#include <stdio.h>

int main() {
	int n;
	scanf("%d",&n);
	if(n <= 0) printf("Invalid input");
	else if(n == 1) printf("1");//1 always has 1 one coprime
	else {
		int count = 0, temp;//count tracks number of coprimes while temp acts as an indicator to detect non co primes
		for(int i = 2; i < n; i++) {//since 1 is coprime to all numbers i started checking for coprimes from 2 all the way up to n-1
			temp = 0;//indicator set to 0 at beginning of check for each number
			for(int j = 2; j <= i; j++){//here i check if i and n have any common divisors except 1 
				if(i%j == 0 && n%j == 0) {
					temp = 1;//if there is any common divisor then temp is set to 1 indicating i is not co prime
					break;//since one common divisor exists we can break out of this loop
				}
			}
			if(temp == 0) count++;//if temp was unchanged then i had to be coprime so we increase count by one
		}
		printf("%d",count+1);//adding one to count at the end because 1 was ignored in the above loops
	}
}
